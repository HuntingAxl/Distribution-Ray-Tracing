#define GLM_FORCE_UNRESTRICTED_GENTYPE

#include <glm/glm.hpp>

int main()
{
	int Error = 0;

	return Error;
}

