//object.h
#ifndef _OBJECT_H_
#define _OBJECT_H_

#include "ray.h"
#include "vector3D.h"
#include "color.h"
#include "material.h"
#include <iostream>

class Object
{
protected:
	bool isSolid;
	int numTransform;	// Number of transformations that have happened.
	Vector3D movementStep;
public:
	Material *material;
	Object(Material *mat, Vector3D _movementStep): material(mat), movementStep(_movementStep) {}
	virtual bool intersect(Ray& ray) const = 0;
	virtual void moveObject(){std::cout<<"Object: moveObject()"<<std::endl;};
	virtual void resetPosition(){};
	virtual Color shade(const Ray& ray) const {
		return material->shade(ray, isSolid);
	}
	Vector3D getPosition(){};
};

#endif
