//
// Created by gurpal on 11/10/17.
//

#include <iostream>
#include "Triangle.h"

bool Triangle::intersect(Ray &r) const {
    Vector3D dir = r.getDirection();
    Vector3D edge_vec1 = v1 - v0;
    Vector3D edge_vec2 = v2 - v0;
    Vector3D pvec = crossProduct(edge_vec2,dir);
    float det = dotProduct(pvec,edge_vec1);
    // ray and triangle are parallel if det is close to 0
//  this one for culling, i.e. back facing triangles are not to be drawn.
    if (det < FLT_EPSILON) return false;
    if (fabs(det) < FLT_EPSILON) return false;

    float invDet = 1 / det;

    Vector3D orig = r.getOrigin();
    Vector3D tvec = orig - v0;
    float u = dotProduct(pvec,tvec) * invDet;
    if (u < 0 || u > 1) return false;

    Vector3D qvec = crossProduct(edge_vec1,tvec);
    float v = dotProduct(qvec,dir) * invDet;
    if (v < 0 || u + v > 1) return false;

    float t = dotProduct(qvec,edge_vec2) * invDet;

    r.setParameter(t,this);
    Vector3D normal(0,0,1);
    r.setNormal(normal);

    return true;
}

void Triangle::moveObject() {
    v0 += movementStep;
    v1 += movementStep;
    v2 += movementStep;
    numTransform++;
}

void Triangle::resetPosition() {
    v0 -= (movementStep*numTransform);
    v1 -= (movementStep*numTransform);
    v2 -= (movementStep*numTransform);
    numTransform=0;
}
