//
// Created by gurpal on 11/10/17.
//

#ifndef ASSIGNMENT4_TRIANGLE_H
#define ASSIGNMENT4_TRIANGLE_H


#include "sphere.h"

class Triangle : public Object{
private:
    Vector3D v0;
    Vector3D v1;
    Vector3D v2;
public:
    const Vector3D &getV0() const { return v0; }
    const Vector3D &getV1() const { return v1; }
    const Vector3D &getV2() const { return v2; }
    Triangle(Vector3D _v0,Vector3D _v1,Vector3D _v2,Material *mat, Vector3D _movementStep) :
        Object(mat, _movementStep), v0(_v0), v1(_v1),v2(_v2) {
        isSolid = true;
    }
    virtual void moveObject();
    virtual void resetPosition();
    virtual bool intersect(Ray &r) const;
};


#endif //ASSIGNMENT4_TRIANGLE_H
