#include "world.h"
#include <iostream>
using namespace std;

float World::firstIntersection(Ray& ray)
{
    for(int i=0; i<objectList.size(); i++)
        objectList[i]->intersect(ray);
    return ray.getParameter();
}

Color phong_shading_ambient(Ray &incident){
    Material* m = incident.intersected()->material;
    float ambient_str = m->ka;
    Color color = m->color;
    return color * ambient_str;
}

Color phong_shading_diff_spec(Ray& incident, LightSource& lightSource){
    Material* m = incident.intersected()->material;
    float diffuse_str = m->kd;
    float specular_str = m->ks;
    float shiny_pow = m->n;

    Color color = m->color;
    Vector3D objectNormal = incident.getNormal();
    Vector3D viewVector = incident.getDirection();
    viewVector.normalize();
    viewVector = viewVector * -1;
    float diff = 0;
    float spec = 0;
    Vector3D lightPos = lightSource.getPosition();
    Vector3D objectPos = incident.getPosition();
    Vector3D lightDir = lightPos - objectPos;
    objectNormal.normalize();
    lightDir.normalize();
    Vector3D halfVector = viewVector+lightDir;
    halfVector.normalize();
    diff += max(dotProduct(lightDir,objectNormal),0.0);
    spec += max(pow(dotProduct(objectNormal,halfVector),shiny_pow),0.0);

    Color final_color(0,0,0);
    Color diffuse_comp = color * diff * diffuse_str;
    Color specular_comp = color * specular_str * spec;

    final_color = diffuse_comp + specular_comp;
    return final_color*lightSource.getIntensity();
}


Color World::shade_ray(Ray& ray) {
    firstIntersection(ray);
    if(ray.didHit()) {
        Color finalColor(0, 0, 0);
        finalColor = phong_shading_ambient(ray);
        Color sumLightColor(0, 0, 0);
        for (LightSource *lightlistElement:lightSourceList) {
            bool makeShadow = false;
            Vector3D lightDirection = (*lightlistElement).getPosition() - ray.getPosition();
            lightDirection.normalize();
            //            Vector3D lightDirection = ray.getPosition() - (*lightlistElement).getPosition();
            Ray Shadow_ray = Ray(ray.getPosition() + lightDirection * 0.001, lightDirection);
            firstIntersection(Shadow_ray);
            Color colorForPointLight = phong_shading_diff_spec(ray, *lightlistElement);
            if (Shadow_ray.didHit()) {
                // condition for non-solid objects.
                if (Shadow_ray.intersected() != ray.intersected()) {
                    makeShadow = true;
                }
            }
            if (!makeShadow)
                sumLightColor = sumLightColor + colorForPointLight;
        }
        float invNumSamples = 1 / (float) lightSourceList.size();
        sumLightColor = sumLightColor * invNumSamples;
        finalColor = finalColor + sumLightColor;
        return finalColor;
//        return ray.intersected()->shade(ray); // Pop in this statement and remove all other statements
                                                // in the if statement above to disable shadows.
    }
    return background;
}


