#include <iostream>
#include "world.h"
#include "material.h"

float max( float a, float b){
	return a>b?a:b;
}

Color Material::shade(const Ray& incident, const bool isSolid) const
{
	std::vector<LightSource*> lightSourceList = world->getLightSourceList();
	float ambient_str = ka;
	float diffuse_str = kd;
	float specular_str = ks;
	float shiny_pow = n;

	Vector3D objectNormal = incident.getNormal();
	Vector3D viewVector = incident.getDirection();
    viewVector.normalize();
    viewVector = viewVector * -1;
	float diff = 0;
    float spec = 0;
	for(int i=0;i<lightSourceList.size();i++){
		Vector3D lightPos = lightSourceList[i]->getPosition();
		Vector3D objectPos = incident.getPosition();
		Vector3D lightDir = lightPos - objectPos;
		objectNormal.normalize();
		lightDir.normalize();
        Vector3D halfVector = viewVector+lightDir;
        halfVector.normalize();
		diff += max(dotProduct(lightDir,objectNormal),0);
		spec += max(pow(dotProduct(objectNormal,halfVector),shiny_pow),0);
	}
    //Phong Shading.
    Color ambient_comp = color * ambient_str;
	Color diffuse_comp = color * diff * diffuse_str;
    Color specular_comp = color * specular_str * spec;
	Color final_color = ambient_comp + diffuse_comp + specular_comp;
	return final_color;
}
