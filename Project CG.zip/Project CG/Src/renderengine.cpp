#include "renderengine.h"

const Color RenderEngine::trace(const int i, const int j) {
    Vector3D ray_dir = camera->get_ray_direction(i, j);
    Ray ray(camera->get_position(), ray_dir);
	return DOF(world->shade_ray(ray), ray);
//    return world->shade_ray(ray);
}

bool RenderEngine::renderLoop()
{
    static int i = 0;
//    bool motionBlur = false;
    bool motionBlur = true;
    for(int j = 0; j<camera->getHeight(); j++) {
        Color finalColor = trace(i,j);
        if(motionBlur) {
            Color color(0, 0, 0);
            float motionBlurFrames = 5.0;
            int int_motionBlurFrames = (int) motionBlurFrames;
            float sum = 1.0;
            for (int k = 2; k <= int_motionBlurFrames; sum += k, k++) {
                world->moveObjects();
                color = color + trace(i, j) * k;
            }
            finalColor = finalColor + color;
            world->resetObjects();
            motionBlurFrames = 1 / sum;
            finalColor = finalColor * motionBlurFrames;
        }
        // Below are steps for anit-aliasing.
        // -- Comment out to use it. --
//        Color color(0,0,0);
//		float invNumOfSamplePixels = 1/(5.0*5.0);
//		for(int m=-2;m<=2;m++){
//			for(int n=-2;n<=2;n++){
//				color = color + trace(i+m, j+n);
//			}
//		}
//        color = color * invNumOfSamplePixels;
        // -- till here. --
        finalColor.clamp();
        camera->drawPixel(i, j, finalColor);
    }

    if(++i == camera->getWidth()) {
        i = 0;
        return true;
    }
    return false;
}

Color RenderEngine::DOF(Color color, Ray &primaryRay){
    float aperture=2.0f;
    Camera *newCamera=camera;
    Vector3D eye = newCamera->get_position();
    float focal_distance= 20.0f;//(objectLocation()-eye).length();
    Vector3D focal_point = eye + focal_distance * primaryRay.getDirection();
//	newCamera->setFocalDistance(focal_distance);
    Vector3D r = newCamera->get_up();
    int n=8;   //no of depth rays per pixel
    float colorRed = 0.0f;
    float colorBlue = 0.0f;
    float colorGreen = 0.0f;
    for (int i = 0; i < n; i++) {
        float rand_radius = static_cast <float> (rand()) / (static_cast <float> (RAND_MAX/aperture));		//gives random in between 0.0 to aperture
        float rand_phi=static_cast <float> (rand()) / (static_cast <float> (RAND_MAX/360));		//gives random in between 0.0 to 360
        Vector3D rayOrigin = Vector3D(eye.X() + rand_radius * cos(rand_phi * M_PI / 180), eye.Y() +
                                                                                          rand_radius * sin(rand_phi * M_PI /
                                                                                                            180), eye.Z());
        Ray secondaryRay(rayOrigin, focal_point-rayOrigin);
        Color c = world->shade_ray(secondaryRay);
        c.clamp();
        colorRed += c.r;
        colorGreen += c.g;
        colorBlue += c.b;
    }
    Color finalColor(colorRed / n, colorGreen / n, colorBlue / n);
    return finalColor;
}